package principales;

import edlineal.Arreglo;
import entradasalida.Salida;

public class principalArreglo {
    public static void main(String[] args) {
        Arreglo lista = new Arreglo(6);
        lista.poner("S");
        lista.poner("T");
        lista.poner("S");
        lista.poner("N");
        lista.poner("S");
        lista.poner("P");





    }
}
