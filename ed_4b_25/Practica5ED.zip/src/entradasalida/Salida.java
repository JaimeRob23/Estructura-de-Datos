package entradasalida;

public class Salida {
    public static void salidaPorDefecto(String cadena){
        System.out.print(cadena);
    }
}
