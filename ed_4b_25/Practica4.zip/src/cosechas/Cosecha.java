package cosechas;

import java.util.Random;

public class Cosecha {
    Object toneladas;

    public Cosecha(){

    }

    public Object mesCosechado(){
     return toneladas;
    }
}
