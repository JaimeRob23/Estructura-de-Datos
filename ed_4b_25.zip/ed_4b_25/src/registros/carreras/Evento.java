package registros.carreras;

public class Evento {
    protected String nombre;
    protected String lugar;
    protected String anioFundacion;

    public Evento(String nombre, String lugar, String anioFundacion) {
        this.nombre = nombre;
        this.lugar = lugar;
        this.anioFundacion = anioFundacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getAnioFundacion() {
        return anioFundacion;
    }

    public void setAnioFundacion(String anioFundacion) {
        this.anioFundacion = anioFundacion;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
