package principales;

import ednolineal.Arreglo3D;

public class PrincipalArreglo3D {
    public static void main(String[] args) {
        Arreglo3D prueba= new Arreglo3D(5,5,5,"Hola");

        prueba.imprimirXColumnas();
    }
}
